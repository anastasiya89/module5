
<h2>Новости</h2>
<?php foreach($data['pages'] as $page_data){ ?>
    <div style="margin-top: 20px;">
        <a href="/pages/view/<?=$page_data['alias']?>"><?=$page_data['title']?></a>
    </div>

<?php } ?>