<?php

return array('lng.test' => 'БУДИНОК МРIЙ',);