function confirmDelete(){
    if(confirm("Вы действительно хотите удалить этот файл?")){
        return true;
    }else{
        return false;
    }
}