<?php
Session::destroy();