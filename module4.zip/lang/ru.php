<?php

return array('lng.test' => 'Дом мечты',);